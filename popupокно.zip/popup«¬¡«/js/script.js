$(document).ready(function(){
    var pp     = $("#pp"),
        bg     = $("#pp-bg");

    function pp_hide(pp, bg){
        pp.animate({bottom: "50px"}, 1000, function(){bg.fadeOut(1000);});
    }

    function pp_show(pp, bg){
        pp.animate({bottom: "50px"}, 2000);
        bg.fadeIn(1000).click(function(){pp_hide(pp, bg)});
    }

    if ( $.cookie('visit') == undefined ){
        $.cookie('visit', true);
        pp_show(pp, bg);
    } else {
        $('body').append('<h1>Вы у нас уже были :)</h1><a href="#" id="remove_cookie">Удалить куки!</a>');
        $('#remove_cookie').click(function(e){
            e.preventDefault();
            $.removeCookie('visit');
            $(this).after("<span>Куки удалены успешно! Перезагрузите страницу :)</span>").remove();
        });
    }
});